import 'package:flutter/material.dart';

import 'package:flutter/cupertino.dart';

import 'package:flutter/material.dart';
import 'package:student/Editpage.dart';

import 'package:student/ModelClass.dart';

class DataCard extends StatelessWidget {
  DataCard({
    Key? key,
    required this.data,
    required this.index,
    required this.delete,
  }) : super(key: key);

  final DataModel data;
  final int index;
  final Function delete;

//final Function edit;

//final int index;

//final Function delete;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Container(
        padding: EdgeInsets.only(left: 20, top: 10, right: 20, bottom: 10),
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Container(
            width: 230,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  data.name,
                  style: TextStyle(
                      color: Colors.green,
                      fontSize: 20,
                      fontWeight: FontWeight.bold),
                ),
                Text(
                  data.email,
                  style: TextStyle(color: Colors.black, fontSize: 15),
                ),
                Text(
                  data.adm_num,
                  style: TextStyle(color: Colors.black, fontSize: 15),
                ),
                Text(
                  data.course,
                  style: TextStyle(color: Colors.black, fontSize: 15),
                ),
                Text(
                  data.phonenum,
                  style: TextStyle(color: Colors.black, fontSize: 15),
                ),
                Text(
                  data.password,
                  style: TextStyle(color: Colors.black, fontSize: 15),
                ),
                Container(
                  alignment: Alignment.center,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        child: Text(
                          "Edit".toUpperCase(),
                          style: TextStyle(color: Colors.white),
                        ),
                        style: ElevatedButton.styleFrom(
                            primary: Colors.blue,
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5))),
                        onPressed: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => EditingPage(
                                    index: index,
                                  )));
                        },
                      ),
                      ElevatedButton(
                          onPressed: () {
                            delete(index);
                            // delete(index);
                          },
                          child: Text(
                            "Delete".toUpperCase(),
                            style: TextStyle(color: Colors.white),
                          ),
                          style: ElevatedButton.styleFrom(
                              primary: Colors.red,
                              padding: EdgeInsets.symmetric(horizontal: 10),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(5))))
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        // SizedBox(
        //   width: 30,
        // ),
      ),
    );
  }
}
