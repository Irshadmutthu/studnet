import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:student/ModelClass.dart';
import 'package:student/database_helper.dart';
import 'package:student/display.dart';

class EditingPage extends StatefulWidget {
  int index;

  EditingPage({required this.index});

  @override
  State<EditingPage> createState() => EditingPageState(this.index);
}

class EditingPageState extends State<EditingPage> {
  int index;
  EditingPageState(this.index);

  final form1Key = GlobalKey<FormState>();

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController courseController = TextEditingController();
  TextEditingController admnumController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController pswController = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    db = DB();
    getDatas();
  }

  void getDatas() async {
    datas = await db.getData();
    setState(() {
      nameController.text = datas[index].name;
      emailController.text = datas[index].email;
      courseController.text = datas[index].course;
      admnumController.text = datas[index].adm_num;
      phoneController.text = datas[index].phonenum;
      pswController.text = datas[index].password;
    });
  }

  late DB db;
  List<DataModel> datas = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("SignUp Page"),
        ),
        body: SingleChildScrollView(
            child: Padding(
          padding: EdgeInsets.all(10),
          child: Form(
            key: form1Key,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Center(
                    child: Text(
                      "SignUp",
                      style: TextStyle(
                        color: Colors.green,
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  TextFormField(
                    controller: nameController,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    decoration: InputDecoration(
                        hintText: "Name",
                        hintStyle: TextStyle(fontSize: 20, color: Colors.black),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(50.0),
                        ),
                        contentPadding: EdgeInsets.fromLTRB(20, 10, 20, 10)),
                    validator: (name) {
                      if (isNameVallidate(name!)) {
                        return null;
                      } else {
                        return "enter correct name";
                      }
                    },
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  TextFormField(
                    controller: emailController,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    decoration: InputDecoration(
                        hintText: "Email",
                        hintStyle: TextStyle(fontSize: 20, color: Colors.black),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(50.0),
                        ),
                        contentPadding: EdgeInsets.fromLTRB(20, 10, 20, 10)),
                    validator: (email) {
                      if (isEmailValidate(email!)) {
                        return null;
                      } else {
                        return "Email is invalid";
                      }
                    },
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  TextFormField(
                    controller: admnumController,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    decoration: InputDecoration(
                        hintText: "Admission Number",
                        hintStyle: TextStyle(fontSize: 20, color: Colors.black),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(50.0),
                        ),
                        contentPadding: EdgeInsets.fromLTRB(20, 10, 20, 10)),
                    validator: (admission_number) {
                      if (isAdmissionValidate(admission_number!)) {
                        return null;
                      } else {
                        return "Admission number is invalid";
                      }
                    },
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  TextFormField(
                    controller: courseController,
                    decoration: InputDecoration(
                        hintText: "Course",
                        hintStyle: TextStyle(fontSize: 20, color: Colors.black),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(50.0),
                        ),
                        contentPadding: EdgeInsets.fromLTRB(20, 10, 20, 10)),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  TextFormField(
                    controller: phoneController,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    decoration: InputDecoration(
                        hintText: "Phone number",
                        hintStyle: TextStyle(fontSize: 20, color: Colors.black),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(50.0),
                        ),
                        contentPadding: EdgeInsets.fromLTRB(20, 10, 20, 10)),
                    validator: (phonenumber) {
                      if (isPhoneValidate(phonenumber!)) {
                        return null;
                      } else {
                        return "Phone  number is invalid";
                      }
                    },
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  TextFormField(
                    controller: pswController,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    decoration: InputDecoration(
                        hintText: "Password",
                        hintStyle: TextStyle(fontSize: 20, color: Colors.black),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(50.0),
                        ),
                        contentPadding: EdgeInsets.fromLTRB(20, 10, 20, 10)),
                    validator: (password) {
                      if (isPassswordValidate(password!)) {
                        return null;
                      } else {
                        return "Password invalid";
                      }
                    },
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  ElevatedButton(
                      onPressed: () {
                        if (form1Key.currentState!.validate()) {
                          DataModel localdata = datas[index];
                          localdata.name = nameController.text;
                          localdata.email = emailController.text;
                          localdata.adm_num = admnumController.text;
                          localdata.course = courseController.text;
                          localdata.phonenum = phoneController.text;
                          localdata.password = pswController.text;
                          db.update(localdata, localdata.id!);
                          Navigator.of(context).pop();

                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => Display()));

                          // use the email provided here
                        }
                      },
                      child: Text(
                        "Save",
                        style: TextStyle(fontSize: 24),
                      ))
                ]),
          ),
        )));
    // TODO: implement build
  }

  bool isEmailValidate(String email) {
    String e_pattern = r"^[a-zA-Z0-9.]+@[a-zA-Z0-9]+\.[a-zA-Z]+";

    RegExp nameReg = RegExp(e_pattern);

    return (nameReg.hasMatch(email) && email != null);
  }

  bool isAdmissionValidate(String adsn_number) {
    String a_pattern = r'[0-9]';
    RegExp admReg = RegExp(a_pattern);
    return (admReg.hasMatch(adsn_number) && admReg != null);
  }

  bool isPhoneValidate(String phone) {
    String a_pattern = r'[0-9]';

    RegExp phonenum = RegExp(phone);
    return (phonenum.hasMatch(phone) && phone != null && phone.length == 10);
  }

  bool isPassswordValidate(String password) {
    return (password.length >= 6 && password.length != null);
  }

  bool isNameVallidate(String namee) {
    return (namee != null);
  }
}
