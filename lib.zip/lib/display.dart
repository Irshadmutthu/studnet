import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:student/Datacard.dart';
import 'package:student/ModelClass.dart';
import 'package:student/database_helper.dart';

class Display extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => DisplayState();
}

class DisplayState extends State {
  late DB db;
  List<DataModel> datas = [];
  bool fetch = true;

  @override
  void initState() {
    db = DB();
    getData1();
    // TODO: implement initState
    super.initState();
  }

  void getData1() async {
    datas = await db.getData();
    fetch = false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Student Details"),
        ),
        body: Center(
          child: fetch
              ? CircularProgressIndicator()
              : ListView.builder(
                  itemBuilder: ((context, index) => DataCard(
                      data: datas[index], index: index, delete: delete)),
                  itemCount: datas.length,
                ),
        ));
  }

  void delete(int index) {
    db.delete(datas[index].id!);
    setState(() {
      datas.removeAt(index);
    });
  }
}
